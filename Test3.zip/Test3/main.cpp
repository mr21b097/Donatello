#include <iostream>
#include <string>
#include <thread>
#include <cstdlib>
#include <cstring>
#include <windows.h>

// Funktion zum Starten einer Exe-Datei in einem neuen Prozess
void runExecutable(const std::string& exePath, const std::string& arguments) {
    // Erstelle den vollständigen Befehl
    std::string commandLine = exePath + " " + arguments;

    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    // Starten des Prozesses
    if (!CreateProcess(
            NULL,             // Kein Modulname
            &commandLine[0],  // Befehl mit Argumenten
            NULL,             // Prozesssicherheit
            NULL,             // Thread-Sicherheit
            FALSE,            // Keine Handle-Vererbung
            0,                // Keine speziellen Erstellungsflags
            NULL,             // Keine Umgebungsvariablen
            NULL,             // Arbeitsverzeichnis
            &si,              // Startinformationen
            &pi)) {           // Prozessinformationen
        std::cerr << "Fehler beim Starten von " << exePath << ": " << GetLastError() << std::endl;
        return;
    }

    // Warten, bis der Prozess beendet ist
    WaitForSingleObject(pi.hProcess, INFINITE);

    // Handles schließen
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
}

int main() {
    // Exe-Pfade anpassen
    std::string serverExePath = "C:\\Users\\Christoph Roth\\Desktop\\APR\\Donatello\\Test3\\server.exe";
    std::string clientExePath = "C:\\Users\\Christoph Roth\\Desktop\\APR\\Donatello\\Test3\\client.exe";

    // Argumente für die Programme
    std::string serverArgs1 = "9997";  //  Serverport
    std::string serverArgs2 = "9998";  //  Serverport
    std::string clientArgs1 = "192.168.100.54 TestMessage 9997";  //  Server IP, Nachricht und Port
    std::string clientArgs2 = "192.168.100.54 TestMessage 9998";  //  Server IP, Nachricht und Port

    // Threads erstellen und Exes ausführen
    std::thread serverThread1(runExecutable, serverExePath, serverArgs1);
    std::thread serverThread2(runExecutable, serverExePath, serverArgs2);

    std::thread clientThread1(runExecutable, clientExePath, clientArgs1);
    std::thread clientThread2(runExecutable, clientExePath, clientArgs2);
    
    // Warten, bis die Threads beendet sind
    serverThread1.join();
    serverThread2.join();
    clientThread1.join();
    clientThread2.join();

    return 0;
}